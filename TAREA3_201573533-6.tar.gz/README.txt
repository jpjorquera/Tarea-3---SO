Para el caso de matrices y funciones, se deben incluir los archivos 'matrices.txt' y 'funciones.txt' para los respectivos problemas en esta misma carpeta. Se provee de los casos de ejemplo, por lo que simplemente basta con modificar estos archivos para realizar otras pruebas.

En el problema de matrices se genera otro archivo en esta carpeta 'matriz_resultante.txt'.

Para compilar, se debe hacer para los 3 ejercicios juntos con:
make

Y para correr cada uno se hace respectivamente con:
make Funciones
make Matrices
make granja